package heroes_villanos;

public enum Caracteristica {
	VELOCIDAD, FUERZA, RESISTENCIA, DESTREZA;
}
